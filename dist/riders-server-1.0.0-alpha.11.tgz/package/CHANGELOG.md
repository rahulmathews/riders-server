## [1.0.0-alpha.11](https://github.com/rahulmathews/riders-server/releases/tag/v1.0.0-alpha.11) (2025-08-10)

Released by: [Rahul](mailto:27402666+rahulmathews@users.noreply.github.com)

Release Date: Aug 10, 2025, 1:54 PM CDT

### 🐛 Bug Fixes

- add GitHub plugin for release creation ([9d9a23d](https://github.com/rahulmathews/riders-server/commit/9d9a23d9ab131bf4fe4252f861afcc9ccaee35db)) - Aug 10, 2025, 1:46 PM CDT by [Rahul](mailto:27402666+rahulmathews@users.noreply.github.com)

- added semantic-release github plugin to handle github releases in CI mode ([5aefbb3](https://github.com/rahulmathews/riders-server/commit/5aefbb3a7eb6a9385d82f9ac3a7a90fb1aa90bdb)) - Aug 10, 2025, 1:52 PM CDT by [Rahul](mailto:27402666+rahulmathews@users.noreply.github.com)

## [1.0.0-alpha.10](https://github.com/rahulmathews/riders-server/releases/tag/v1.0.0-alpha.10) (2025-08-10)

Released by: [Rahul](mailto:27402666+rahulmathews@users.noreply.github.com)

Release Date: Aug 10, 2025, 1:42 PM CDT

### 🐛 Bug Fixes

- test release notes formatting ([ee9a578](https://github.com/rahulmathews/riders-server/commit/ee9a5784719b3d7c1b638f71e10dd8579169305d)) - Aug 10, 2025, 1:40 PM CDT by [Rahul](mailto:27402666+rahulmathews@users.noreply.github.com)

## [1.0.0-alpha.9](https://github.com/rahulmathews/riders-server/releases/tag/v1.0.0-alpha.9) (2025-08-10)
Released by: [Rahul](mailto:27402666+rahulmathews@users.noreply.github.com)

Release Date: Aug 10, 2025, 1:33 PM CDT

### 🐛 Bug Fixes

- removed changelog headers ([604b61d](https://github.com/rahulmathews/riders-server/commit/604b61db2796025043f951f1b9cf899ff00de143)) - Aug 10, 2025, 1:32 PM CDT by [Rahul](mailto:27402666+rahulmathews@users.noreply.github.com)

## [1.0.0-alpha.8](https://github.com/rahulmathews/riders-server/releases/tag/v1.0.0-alpha.8) (2025-08-10)
Released by: [Rahul](mailto:27402666+rahulmathews@users.noreply.github.com)

Release Date: Aug 10, 2025, 1:27 PM CDT

### 🐛 Bug Fixes

- fixed husky interference in the @semantic-release/npm stage ([29ddae4](https://github.com/rahulmathews/riders-server/commit/29ddae47d6ef5b828880cccfb58453f6e1706b7a)) - Aug 10, 2025, 1:26 PM CDT by [Rahul](mailto:27402666+rahulmathews@users.noreply.github.com)

- improved changelog generation with pipeline ([02bced0](https://github.com/rahulmathews/riders-server/commit/02bced0358769ea24070256b7616710c703b4baf)) - Aug 10, 2025, 12:24 PM CDT by [Rahul](mailto:27402666+rahulmathews@users.noreply.github.com)

- improved changelog generation with pipeline and fixed some issues ([22242f6](https://github.com/rahulmathews/riders-server/commit/22242f6e16497625def13230d8902e4297d6f5de)) - Aug 10, 2025, 1:15 PM CDT by [Rahul](mailto:27402666+rahulmathews@users.noreply.github.com)


### 🔀 Pull Requests

- Merged branch origin/develop ([30dd37e](https://github.com/rahulmathews/riders-server/commit/30dd37e4203a1bb8ef980c8ca18e226ac31edff1)) - Aug 10, 2025, 11:52 AM CDT by [Rahul](mailto:27402666+rahulmathews@users.noreply.github.com)


### 🏗️ Build System

- empty build ([113724b](https://github.com/rahulmathews/riders-server/commit/113724b658595043b760e157b20d66fe2521e81e)) - Aug 10, 2025, 11:23 AM CDT by [Rahul](mailto:27402666+rahulmathews@users.noreply.github.com)


# [1.0.0-alpha.7](https://github.com/rahulmathews/riders-server/compare/v1.0.0-alpha.6...v1.0.0-alpha.7) (2025-08-10)


### Bug Fixes

* empty commit ([7fbb0ca](https://github.com/rahulmathews/riders-server/commit/7fbb0caf4567c767285ab7731f449192cac61d7f))

# [1.0.0-alpha.6](https://github.com/rahulmathews/riders-server/compare/v1.0.0-alpha.5...v1.0.0-alpha.6) (2025-08-10)

# [1.0.0-alpha.5](https://github.com/rahulmathews/riders-server/compare/v1.0.0-alpha.4...v1.0.0-alpha.5) (2025-08-10)

## [1.0.0-alpha.4](https://github.com/rahulmathews/riders-server/compare/v1.0.0-alpha.3...v1.0.0-alpha.4) (2025-08-10)

### Bug Fixes

- added perms needed for release
  ([10071ca](https://github.com/rahulmathews/riders-server/commit/10071cacf8e58444c9baa370307408e6a74a3c62))
- adds perms for scripts/\* and adds HUSKY env var to skip pre-commit hooks for
  semantic-release
  ([c315ed6](https://github.com/rahulmathews/riders-server/commit/c315ed6bd896829c5c5cdf36dfd0e34f11319d25))
- fixed formatting issue
  ([2fe6155](https://github.com/rahulmathews/riders-server/commit/2fe6155e555fcbe7d7ce2d56c6d5e4030500a711))
- ignored commit lint body length checks for chore(release)
  ([81f4fd1](https://github.com/rahulmathews/riders-server/commit/81f4fd1f06fa5c775a110e866472f4628a9481d9))
- improved error handling for pre-commit hooks
  ([b150625](https://github.com/rahulmathews/riders-server/commit/b150625a2d04ab04fb7f2e5ffc7f110f447f86e1))
- removed semantic-release/npm to fix releases
  ([0726aca](https://github.com/rahulmathews/riders-server/commit/0726acacfff478e574f9248682d68a5ba8f1e111))
- skips pre-commit hooks for semantic release
  ([eebc572](https://github.com/rahulmathews/riders-server/commit/eebc572bdd09d693aceb11767d1c49ba83ed871c))

## [1.0.0-alpha.3](https://github.com/rahulmathews/riders-server/compare/v1.0.0-alpha.2...v1.0.0-alpha.3) (2025-08-10)

### Bug Fixes

- added perms needed for release
  ([10071ca](https://github.com/rahulmathews/riders-server/commit/10071cacf8e58444c9baa370307408e6a74a3c62))
- fixed formatting issue
  ([2fe6155](https://github.com/rahulmathews/riders-server/commit/2fe6155e555fcbe7d7ce2d56c6d5e4030500a711))
- ignored commit lint body length checks for chore(release)
  ([81f4fd1](https://github.com/rahulmathews/riders-server/commit/81f4fd1f06fa5c775a110e866472f4628a9481d9))
- improved error handling for pre-commit hooks
  ([b150625](https://github.com/rahulmathews/riders-server/commit/b150625a2d04ab04fb7f2e5ffc7f110f447f86e1))
- removed semantic-release/npm to fix releases
  ([0726aca](https://github.com/rahulmathews/riders-server/commit/0726acacfff478e574f9248682d68a5ba8f1e111))
- skips pre-commit hooks for semantic release
  ([eebc572](https://github.com/rahulmathews/riders-server/commit/eebc572bdd09d693aceb11767d1c49ba83ed871c))

## [1.0.0-alpha.2](https://github.com/rahulmathews/riders-server/compare/v1.0.0-alpha.1...v1.0.0-alpha.2) (2025-08-10)

### Features

- implemented environment-specific configurations
  ([d51df55](https://github.com/rahulmathews/riders-server/commit/d51df55912390aa3f281346089864b05c4a155f3))

## [1.0.0-alpha.1](https://github.com/rahulmathews/riders-server/releases/tag/v1.0.0-alpha.1) (2025-08-10)

### Bug Fixes

- fixed release workflow
  ([38d49d4](https://github.com/rahulmathews/riders-server/commit/38d49d4ee5e57b3d566d9669556128e7ba5e3d02))
- fixed some formatting and added formatting as a part of github workflow
  ([d790634](https://github.com/rahulmathews/riders-server/commit/d79063484bf7b86de6c1e113a09f1222679012db))
- improved github workflow and fixed release workflow
  ([ea82b1a](https://github.com/rahulmathews/riders-server/commit/ea82b1a4d55d33beeb1a7acc372b8fde502e6d85))
- resolve semantic-release commit message length issue
  ([24bb4ac](https://github.com/rahulmathews/riders-server/commit/24bb4ac687b8860c2749d3b630c668a1cd65bb2e))

### Features

- setup github workflows for release management and automated versioning
  ([b29d17e](https://github.com/rahulmathews/riders-server/commit/b29d17e90602402ba2c903775324682e852bf20c))
